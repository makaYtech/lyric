import 'dart:convert';
import '../core/network/epos_http_client.dart';
import '../models/student_profile.dart';
import 'auth_service.dart';

class ProfileService {
  Future<StudentProfile> fetchProfile(EposTokens tokens) async {
    final url = Uri.parse(
      'https://edu-epos.permkrai.ru/core/api/student_profiles/'
      '${tokens.profileId}?pid=${tokens.profileId}',
    );

    final client = await createEposHttpClient();
    try {
      final response = await client.get(
        url,
        headers: {
          'Auth-Token': tokens.authToken,
          'Profile-Id': tokens.profileId,
          'Accept': 'application/json',
        },
      );

      if (response.statusCode != 200) {
        throw Exception(
          'Сервер вернул ${response.statusCode}: ${response.body}',
        );
      }

      final decoded =
          jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
      return StudentProfile.fromJson(decoded);
    } finally {
      client.close();
    }
  }
}
