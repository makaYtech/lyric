/// Один предмет из ответа /reports/api/progress/json.
class SubjectGrade {
  final String subjectName;
  final String avgFive;

  SubjectGrade({required this.subjectName, required this.avgFive});

  factory SubjectGrade.fromJson(Map<String, dynamic> json) {
    return SubjectGrade(
      subjectName: json['subject_name'] as String,
      avgFive: json['avg_five'] as String,
    );
  }

  Map<String, dynamic> toJson() => {
        'subject_name': subjectName,
        'avg_five': avgFive,
      };

  /// "0.00" значит оценок ещё нет — показываем это честно,
  /// а не как средний балл 0.
  String get displayGrade {
    final value = double.tryParse(avgFive) ?? 0;
    if (value == 0) return 'нет оценок';
    return value.toStringAsFixed(2);
  }
}
