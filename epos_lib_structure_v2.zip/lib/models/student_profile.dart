/// ФИО, класс и профиль обучения — вытянуты из полного ответа
/// /core/api/student_profiles/{id}. Ответ там гораздо больше (учителя и т.д.),
/// но пока берём только то, что показываем на экране.
class StudentProfile {
  final String userName;
  final String className;
  final String curriculumName;

  StudentProfile({
    required this.userName,
    required this.className,
    required this.curriculumName,
  });

  factory StudentProfile.fromJson(Map<String, dynamic> json) {
    final classUnit = json['class_unit'] as Map<String, dynamic>?;
    final curricula = json['curricula'] as Map<String, dynamic>?;
    return StudentProfile(
      userName: json['user_name'] as String? ?? '—',
      className: classUnit?['name'] as String? ?? '—',
      curriculumName: curricula?['name'] as String? ?? '—',
    );
  }

  /// Упрощённая форма для кэша — не полный ответ API, а только то,
  /// что реально показываем (полный ответ хранить в кэше избыточно).
  Map<String, dynamic> toJson() => {
        'user_name': userName,
        'class_unit': {'name': className},
        'curricula': {'name': curriculumName},
      };
}
