import 'package:flutter/material.dart';
import '../models/student_profile.dart';
import '../widgets/async_state_view.dart';

/// Чисто отображение — данные и состояние загрузки приходят снаружи
/// (из HomeScreen), сам виджет ничего не грузит и не кэширует.
class ProfileView extends StatelessWidget {
  final StudentProfile? profile;
  final bool isLoading;
  final String? error;

  const ProfileView({
    super.key,
    required this.profile,
    required this.isLoading,
    required this.error,
  });

  @override
  Widget build(BuildContext context) {
    return AsyncStateView(
      isLoading: isLoading,
      error: error,
      hasData: profile != null,
      contentBuilder: (context) => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _InfoTile(label: 'ФИО', value: profile!.userName),
          const Divider(height: 24),
          _InfoTile(label: 'Класс', value: profile!.className),
          const Divider(height: 24),
          _InfoTile(label: 'Профиль обучения', value: profile!.curriculumName),
        ],
      ),
    );
  }
}

class _InfoTile extends StatelessWidget {
  final String label;
  final String value;

  const _InfoTile({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: Theme.of(context)
              .textTheme
              .labelMedium
              ?.copyWith(color: Colors.grey),
        ),
        const SizedBox(height: 4),
        Text(value, style: Theme.of(context).textTheme.titleMedium),
      ],
    );
  }
}
