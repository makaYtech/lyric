import 'package:flutter/material.dart';
import '../models/academic_year.dart';
import '../models/subject_grade.dart';
import '../widgets/async_state_view.dart';

class GradesView extends StatelessWidget {
  final List<SubjectGrade>? grades;
  final List<AcademicYear>? years;
  final int selectedYearId;
  final ValueChanged<int> onYearChanged;
  final bool isLoading;
  final String? error;

  const GradesView({
    super.key,
    required this.grades,
    required this.years,
    required this.selectedYearId,
    required this.onYearChanged,
    required this.isLoading,
    required this.error,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        if (years != null && years!.isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: DropdownButtonFormField<int>(
              value: selectedYearId,
              decoration: const InputDecoration(
                labelText: 'Учебный год',
                border: OutlineInputBorder(),
                isDense: true,
              ),
              items: years!
                  .map(
                    (y) => DropdownMenuItem(value: y.id, child: Text(y.name)),
                  )
                  .toList(),
              onChanged: (value) {
                if (value != null) onYearChanged(value);
              },
            ),
          ),
        Expanded(
          child: AsyncStateView(
            isLoading: isLoading,
            error: error,
            hasData: grades != null,
            contentBuilder: (context) => ListView.separated(
              itemCount: grades!.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, index) {
                final subject = grades![index];
                return ListTile(
                  title: Text(subject.subjectName),
                  trailing: Text(
                    subject.displayGrade,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                );
              },
            ),
          ),
        ),
      ],
    );
  }
}
